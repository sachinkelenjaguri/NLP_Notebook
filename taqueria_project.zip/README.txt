Taqueria Los Portales - JavaFX Project
=====================================

Structure:
- src/main/java/com/taqueria  (Java source files)
- src/main/java/com/taqueria/controller (Controller)
- src/main/resources/view/main.fxml (FXML for Scene Builder)
- pom.xml (Maven build file)

How to run:
1. Install Java 17+ and Maven.
2. From the project root directory, run:
   mvn clean javafx:run
3. Alternatively import the project into IntelliJ or Eclipse (as a Maven project) and run the 'Driver' main.

What is included:
- Entry, Seating, Menu (abstract), Drinks, Appetizer, Entree, Sides, Dessert, Payment, Driver, MainController
- A SceneBuilder-ready FXML (main.fxml)

Notes:
- The project uses clean OOP: abstraction, inheritance, polymorphism, encapsulation.
- Alcoholic drink age validation uses DatePicker (birthday).
- Prices use doubles and are formatted when displayed.

