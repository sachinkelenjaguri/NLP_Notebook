package com.taqueria.controller;

import com.taqueria.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

public class MainController {

    @FXML private Label welcomeLabel;
    @FXML private TextField partySizeField;
    @FXML private DatePicker birthdayPicker;

    @FXML private ComboBox<String> drinksCombo;
    @FXML private Spinner<Integer> shotsSpinner;
    @FXML private CheckBox alcoholicCheck;

    @FXML private ComboBox<String> appetizerCombo;
    @FXML private CheckBox appGuac;
    @FXML private CheckBox appQueso;

    @FXML private ComboBox<String> entreeCombo;
    @FXML private ComboBox<String> proteinCombo;
    @FXML private CheckBox addQuesoEntree;
    @FXML private CheckBox addGuacEntree;
    @FXML private CheckBox removeSour;
    @FXML private CheckBox removePico;

    @FXML private Spinner<Integer> riceSpinner;
    @FXML private Spinner<Integer> beansSpinner;
    @FXML private Spinner<Integer> refriedSpinner;
    @FXML private Spinner<Integer> salsaSpinner;

    @FXML private ComboBox<String> dessertCombo;
    @FXML private CheckBox chocTopping;
    @FXML private CheckBox cherryTopping;
    @FXML private CheckBox caramelTopping;

    @FXML private Button addItemButton;
    @FXML private ListView<String> orderListView;
    @FXML private Label totalLabel;
    @FXML private TextField tipField;
    @FXML private Label tipLabel;
    @FXML private Label grandTotalLabel;

    private final ObservableList<String> orderDisplay = FXCollections.observableArrayList();
    private final List<Menu> orderItems = new ArrayList<>();

    @FXML
    public void initialize() {
        welcomeLabel.setText(new Entry().welcome());
        drinksCombo.getItems().addAll("Water - $0.00", "Soda - $3.00", "Horchata - $2.50", "Alcoholic Drink - $8.00");
        appetizerCombo.getItems().addAll("Beef Empanadas - $8.00", "Tostadas - $7.99", "Chips & Salsa - $5.99");
        entreeCombo.getItems().addAll("Fajita Quesadilla - $13.99", "Carne Asada - $19.99", "Burrito - $13.99/11.99", "Enchiladas - $15.99/13.99");
        proteinCombo.getItems().addAll("Beef","Chicken");
        dessertCombo.getItems().addAll("Tres Leches - $6.99","Fried Ice Cream - $11.99","Churros - $3.99");

        shotsSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0,10,0));
        riceSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0,5,0));
        beansSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0,5,0));
        refriedSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0,5,0));
        salsaSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0,5,0));

        orderListView.setItems(orderDisplay);
    }

    @FXML
    protected void onAddItem(ActionEvent e) {
        try {
            // Drinks
            String dsel = drinksCombo.getValue();
            if (dsel != null) {
                if (dsel.startsWith("Water")) {
                    Drinks d = new Drinks("Water", 0.0, false);
                    orderItems.add(d);
                    orderDisplay.add(d.toString());
                } else if (dsel.startsWith("Soda")) {
                    Drinks d = new Drinks("Soda", 3.0, false);
                    orderItems.add(d);
                    orderDisplay.add(d.toString());
                } else if (dsel.startsWith("Horchata")) {
                    Drinks d = new Drinks("Horchata", 2.5, false);
                    orderItems.add(d);
                    orderDisplay.add(d.toString());
                } else if (dsel.startsWith("Alcoholic")) {
                    // validate age
                    if (birthdayPicker.getValue() == null) throw new IllegalArgumentException("Please enter birthday for alcoholic drink.");
                    int age = Period.between(birthdayPicker.getValue(), LocalDate.now()).getYears();
                    Drinks d = new Drinks("Alcoholic Drink", 8.0, true);
                    d.setShots(shotsSpinner.getValue());
                    d.validateAge(age);
                    orderItems.add(d);
                    orderDisplay.add(String.format("%s (%d shot(s)) - $%.2f", d.getItemName(), shotsSpinner.getValue(), d.calculatePrice()));
                }
            }

            // Appetizer
            String asel = appetizerCombo.getValue();
            if (asel != null) {
                double price = asel.contains("Empanadas") ? 8.0 : asel.contains("Tostadas") ? 7.99 : 5.99;
                Appetizer a = new Appetizer(asel.split(" - ")[0], price);
                a.setAddGuac(appGuac.isSelected());
                a.setAddQueso(appQueso.isSelected());
                orderItems.add(a);
                orderDisplay.add(a.toString());
            }

            // Entree
            String esel = entreeCombo.getValue();
            if (esel != null) {
                double base = 13.99;
                if (esel.startsWith("Carne Asada")) base = 19.99;
                Entree ent = new Entree(esel.split(" - ")[0], base);
                String protein = proteinCombo.getValue();
                if (esel.toLowerCase().contains("burrito") && protein != null) ent.setProtein(protein);
                if (esel.toLowerCase().contains("enchilad") && protein != null) ent.setProtein(protein);
                ent.setAddQueso(addQuesoEntree.isSelected());
                ent.setAddGuac(addGuacEntree.isSelected());
                ent.setRemovePico(removePico.isSelected());
                ent.setRemoveSour(removeSour.isSelected());
                orderItems.add(ent);
                orderDisplay.add(ent.toString());
            }

            // Sides
            if (riceSpinner.getValue() > 0) {
                Sides s = new Sides("Rice", 1.50, riceSpinner.getValue());
                orderItems.add(s);
                orderDisplay.add(s.toString());
            }
            if (beansSpinner.getValue() > 0) {
                Sides s = new Sides("Beans", 2.00, beansSpinner.getValue());
                orderItems.add(s);
                orderDisplay.add(s.toString());
            }
            if (refriedSpinner.getValue() > 0) {
                Sides s = new Sides("Refried Beans", 1.75, refriedSpinner.getValue());
                orderItems.add(s);
                orderDisplay.add(s.toString());
            }
            if (salsaSpinner.getValue() > 0) {
                Sides s = new Sides("Salsa", 0.50, salsaSpinner.getValue());
                orderItems.add(s);
                orderDisplay.add(s.toString());
            }

            // Dessert
            String dres = dessertCombo.getValue();
            if (dres != null) {
                double price = dres.contains("Tres Leches") ? 6.99 : dres.contains("Fried Ice Cream") ? 11.99 : 3.99;
                Dessert ds = new Dessert(dres.split(" - ")[0], price);
                ds.setAddChocolate(chocTopping.isSelected());
                ds.setAddCherry(cherryTopping.isSelected());
                ds.setAddCaramel(caramelTopping.isSelected());
                orderItems.add(ds);
                orderDisplay.add(ds.toString());
            }

            updateTotals();
        } catch (Exception ex) {
            Alert a = new Alert(Alert.AlertType.ERROR, ex.getMessage(), ButtonType.OK);
            a.showAndWait();
        }
    }

    @FXML
    protected void onCalculateTip(ActionEvent e) {
        try {
            double total = Payment.calculateTotal(orderItems);
            double tipPercent = 0.0;
            if (tipField.getText() != null && !tipField.getText().isEmpty()) {
                tipPercent = Double.parseDouble(tipField.getText());
            }
            double tip = Payment.calculateTip(total, tipPercent);
            tipLabel.setText(String.format("$%.2f", tip));
            grandTotalLabel.setText(String.format("$%.2f", total + tip));
        } catch (Exception ex) {
            Alert a = new Alert(Alert.AlertType.ERROR, "Invalid tip input.");
            a.showAndWait();
        }
    }

    private void updateTotals() {
        double total = Payment.calculateTotal(orderItems);
        totalLabel.setText(String.format("$%.2f", total));
        tipLabel.setText("$0.00");
        grandTotalLabel.setText(String.format("$%.2f", total));
    }
}
