package com.taqueria;

public class Drinks extends Menu {
    private boolean alcoholic;
    private int shots;

    public Drinks(String name, double price, boolean alcoholic) {
        super(name, price);
        this.alcoholic = alcoholic;
        this.shots = 0;
    }

    public void setShots(int shots) {
        if (shots < 0) throw new IllegalArgumentException("Shots cannot be negative.");
        this.shots = shots;
    }

    public void validateAge(int age) {
        if (alcoholic && age < 21) {
            throw new IllegalArgumentException("Customer must be at least 21 for alcoholic drinks.");
        }
    }

    @Override
    public double calculatePrice() {
        if (alcoholic) {
            // base price may represent a single shot; we charge $8 per shot as per spec
            return price * Math.max(1, shots);
        } else {
            return price;
        }
    }
}
