package com.taqueria;

public class Appetizer extends Menu {
    private boolean addGuac;
    private boolean addQueso;

    public Appetizer(String name, double price) {
        super(name, price);
    }

    public void setAddGuac(boolean addGuac) { this.addGuac = addGuac; }
    public void setAddQueso(boolean addQueso) { this.addQueso = addQueso; }

    @Override
    public double calculatePrice() {
        double total = price;
        if (addGuac) total += 2.50;
        if (addQueso) total += 2.50;
        return total;
    }
}
