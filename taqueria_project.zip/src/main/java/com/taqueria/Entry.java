package com.taqueria;

public class Entry {
    public String welcome() {
        return "Welcome to Taqueria Los Portales!";
    }
}
