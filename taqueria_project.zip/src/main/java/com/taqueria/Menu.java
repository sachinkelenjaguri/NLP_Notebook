package com.taqueria;

public abstract class Menu {
    protected String itemName;
    protected double price;

    public Menu() {}

    public Menu(String name, double price) {
        this.itemName = name;
        this.price = price;
    }

    public String getItemName() { return itemName; }
    public double getPrice() { return price; }

    public abstract double calculatePrice();

    @Override
    public String toString() {
        return String.format("%s - $%.2f", itemName, calculatePrice());
    }
}
