package com.taqueria;

public class Sides extends Menu {
    private int quantity;

    public Sides(String name, double price, int qty) {
        super(name, price);
        this.quantity = Math.max(0, qty);
    }

    public void setQuantity(int q) { this.quantity = Math.max(0, q); }

    @Override
    public double calculatePrice() {
        return price * quantity;
    }
}
