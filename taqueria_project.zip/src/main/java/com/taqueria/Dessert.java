package com.taqueria;

public class Dessert extends Menu {
    private boolean addChocolate;
    private boolean addCherry;
    private boolean addCaramel;

    public Dessert(String name, double price) {
        super(name, price);
    }

    public void setAddChocolate(boolean addChocolate) { this.addChocolate = addChocolate; }
    public void setAddCherry(boolean addCherry) { this.addCherry = addCherry; }
    public void setAddCaramel(boolean addCaramel) { this.addCaramel = addCaramel; }

    @Override
    public double calculatePrice() {
        double total = price;
        if (addChocolate) total += 0.75;
        if (addCherry) total += 0.50;
        if (addCaramel) total += 0.75;
        return total;
    }
}
