package com.taqueria;

public class Seating {
    private int partySize;

    public void setPartySize(int size) {
        if (size < 1 || size > 5) {
            throw new IllegalArgumentException("Party size must be between 1 and 5.");
        }
        this.partySize = size;
    }

    public int getPartySize() {
        return partySize;
    }
}
