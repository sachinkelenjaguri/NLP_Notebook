package com.taqueria;

public class Entree extends Menu {
    private String protein; // "Beef" or "Chicken"
    private boolean addQueso;
    private boolean addGuac;
    private boolean removeSour;
    private boolean removePico;
    private boolean removeCheese;
    private boolean removeLettuce;
    private String sauceColor; // "Green" or "Red"

    public Entree(String name, double price) {
        super(name, price);
    }

    public void setProtein(String protein) { this.protein = protein; }
    public void setAddQueso(boolean addQueso) { this.addQueso = addQueso; }
    public void setAddGuac(boolean addGuac) { this.addGuac = addGuac; }
    public void setRemoveSour(boolean removeSour) { this.removeSour = removeSour; }
    public void setRemovePico(boolean removePico) { this.removePico = removePico; }
    public void setRemoveCheese(boolean removeCheese) { this.removeCheese = removeCheese; }
    public void setRemoveLettuce(boolean removeLettuce) { this.removeLettuce = removeLettuce; }
    public void setSauceColor(String sauceColor) { this.sauceColor = sauceColor; }

    @Override
    public double calculatePrice() {
        double total = price;
        if (itemName.toLowerCase().contains("burrito")) {
            if ("Beef".equalsIgnoreCase(protein)) total = 13.99;
            else total = 11.99;
        } else if (itemName.toLowerCase().contains("enchilada")) {
            if ("Beef".equalsIgnoreCase(protein)) total = 15.99;
            else total = 13.99;
        }
        if (addQueso) total += 1.50;
        if (addGuac) total += 2.30;
        // Removing ingredients does not change price in this implementation
        return total;
    }
}
