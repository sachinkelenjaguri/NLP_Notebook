package com.taqueria;

import java.util.List;

public class Payment {
    public static double calculateTotal(List<Menu> items) {
        return items.stream().mapToDouble(Menu::calculatePrice).sum();
    }

    public static double calculateTip(double total, double percent) {
        return total * percent / 100.0;
    }
}
